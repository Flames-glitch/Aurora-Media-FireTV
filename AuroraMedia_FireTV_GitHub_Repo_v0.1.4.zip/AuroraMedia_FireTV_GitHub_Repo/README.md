# Aurora Media — Fire TV Edition (0.1.4 prototype)

Independent Android TV project for **basic Fire TV Stick / Fire OS 5.2.9.5** (Android 5.1 / API 22). Does not replace the Aurora Media phone application or the AuroraTV IPTV application.

## What it does
- FTP only (passive mode). One-time server setup (host, port, username, password). Server IP defaults to `192.168.1.254` but remains editable; the media folder is fixed to `/usb1_1/movies` and cannot be changed in the UI.
- Recursively discovers files on launch or manual rescan, shows cached posters immediately, and matches TMDb movie/TV metadata using filenames.
- TMDb v3 API key is **hardcoded in `app/build.gradle.kts` at the owner's request**. This key is visible in source and extractable from APK. If you publish this repository, others can use the key. Rotate it if abuse occurs. Never hardcode FTP credentials.
- VLC playback with play/pause, left/right seeking, media remote keys, aspect-ratio selection, audio/subtitle track switching and resume.
- No picture-in-picture, touch gestures, mobile features, SFTP or IPTV.
- On Fire OS 5, FTP credentials are stored in app-private SharedPreferences **without encryption at rest** (Android Keystore AES APIs used in the phone edition require newer Android). The app opts out of Android Backup. Use on a trusted LAN, do not expose port 21 to the internet.

## Fire TV remote
- In library: D-pad selects posters, Select opens info/play; Menu rescans; buttons access FTP Settings / Rescan.
- In player: play/pause remote key toggles; media rewind/forward jump 30s. Left/right on video jumps 10s. Up brings up playback controls. Menu toggles controls. Back exits playback.
- Control bar includes Back, ±30s, Pause, Aspect, Audio and Subtitles.

## GitHub mobile build (one ZIP upload)
Upload `AuroraMedia_FireTV_GitHub_Repo_v0.1.4.zip` to the **root** of a GitHub repository; do not extract it on the phone. Create `.github/workflows/build-firetv.yml` at the repository root and paste the **external** workflow provided with this ZIP. That workflow unzips the project and runs `gradle :app:assembleDebug` using Java 17/Gradle 8.9/SDK 35, producing a debug-signed APK automatically.

## Practical limitations / test plan
- **Unverified full Android compile** in the artifact generation environment; the GitHub Actions build is the actual Android compile test.
- The LibVLC dependency has broad decoding support, but performance on an original 2nd-generation Fire TV Stick (including software-only video codecs like some HEVC files) will be limited. 720p or compatible H.264 1080p is the realistic first test.
- Older TLS certificate chains / Wi-Fi connectivity can cause TMDb poster failures; verify DNS, system date/time and HTTPS connectivity. Metadata network failures do not prevent FTP file browsing.
- The app itself does not transcode incompatible videos.
- When updating this project, increase `versionCode` and keep APK signing consistent. GitHub's default debug signing keys can change between runs and may require reinstalling after backing up FTP settings.
- No online subtitle search, subtitle delay controls or full equalizer in this first TV prototype.

## Tech
Kotlin / Android framework Views (no Compose dependency), Apache Commons Net FTP, libVLC-all 3.5.1, on-device JSON library cache, constrained bitmap poster cache. `minSdk=22`, `targetSdk=28`, `compileSdk=35`. Native apps can be compatible with Fire OS 5 even when they compile with newer Android SDKs; actual minimum requirements of resolved dependencies must be verified by the build.

## Attribution
Movie data/images from TMDb. This product uses the TMDb API but is not endorsed or certified by TMDb.

### v0.1.1 build fix
Enabled `android.useAndroidX=true` because LibVLC 3.5.1 depends on AndroidX libraries. No app features changed.

### v0.1.2 build fix
Fixed typo in `PlayerActivity.kt` remote key handling (`KEYCODE_HEADSETPHOOK` to `KEYCODE_HEADSETHOOK`).

### v0.1.3 Fire OS 5 runtime compatibility fix
Pinned Apache Commons Net to `3.8.0` instead of `3.11.1` to avoid `java.time.Duration` references unavailable on Android 5.1 (API 22) during FTP setup. This avoids increasing the minimum Android version. All FTP features remain unchanged.

If FTP setup still fails after installing this version, inspect the **new** exact error: login rejected, invalid server address, passive-mode connection, permissions, or inaccessible FTP folder need different fixes. APK still needs validation on real hardware.

### v0.1.4 Fire TV FTP setup usability changes
- Prepopulates the editable FTP host with `192.168.1.254` for new setups, and preserves an existing saved custom host.
- Locks the scanned FTP folder to `/usb1_1/movies` (on-screen shown as read-only, normalized to an absolute FTP path). Previously saved paths are ignored.
- Explicitly masks the password in the app's EditText after returning from Fire TV's on-screen keyboard, disables suggestions, and requests no full-screen IME extraction. The Amazon keyboard UI is owned by Fire OS and may briefly show characters while typing; the app cannot override system keyboard rendering.
- FTP password remains stored in app-private preferences without encryption on Android 5.1. Masking does not encrypt stored credentials.
