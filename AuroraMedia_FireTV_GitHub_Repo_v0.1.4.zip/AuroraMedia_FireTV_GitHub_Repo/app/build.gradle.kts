plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aurora.media.firetv"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aurora.media.firetv"
        minSdk = 22 // Fire OS 5 / Android 5.1
        targetSdk = 28
        versionCode = 5
        versionName = "0.1.4-firetv"
        // Public client-side key supplied by the project owner. Can be extracted from the APK.
        buildConfigField("String", "TMDB_API_KEY", "\"93f714b28c8b82775ed0547176a57c37\"")
    }

    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { jniLibs.useLegacyPackaging = true }
}

dependencies {
    implementation("org.jetbrains.kotlin:kotlin-stdlib:2.0.21")
    implementation("commons-net:commons-net:3.8.0")
    implementation("org.videolan.android:libvlc-all:3.5.1")
}
