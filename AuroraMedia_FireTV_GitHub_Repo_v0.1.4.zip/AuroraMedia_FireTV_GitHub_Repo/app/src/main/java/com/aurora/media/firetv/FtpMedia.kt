package com.aurora.media.firetv

import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import java.net.URI
import java.net.URLEncoder

/** Passive FTP only. No SFTP, media-server software or transcoding. */
object FtpMedia {
    private fun root(path: String) = "/" + path.trim().trim('/').takeIf { it.isNotEmpty() }.orEmpty()
    private fun ftp(a: FtpAccount): FTPClient {
        val client = FTPClient()
        client.connectTimeout = 10_000
        client.defaultTimeout = 10_000
        @Suppress("DEPRECATION")
        client.setDataTimeout(20_000)
        client.controlEncoding = "UTF-8"
        try {
            client.connect(a.host.trim(), a.port)
            if (!client.login(a.user, a.password)) error("FTP login rejected")
            client.enterLocalPassiveMode()
            check(client.setFileType(FTP.BINARY_FILE_TYPE)) { "FTP binary transfer is unavailable" }
            return client
        } catch (e: Exception) {
            if (client.isConnected) runCatching { client.disconnect() }
            throw e
        }
    }
    private inline fun <T> using(a: FtpAccount, block: (FTPClient) -> T): T {
        val client = ftp(a)
        return try { block(client) } finally {
            runCatching { client.logout() }; runCatching { client.disconnect() }
        }
    }
    fun test(a: FtpAccount) = using(a) {
        check(it.changeWorkingDirectory(root(FIRETV_MEDIA_FOLDER))) { "FTP folder cannot be accessed: ${root(FIRETV_MEDIA_FOLDER)}" }
    }
    fun scan(a: FtpAccount, maxFiles: Int = 4000): List<Video> = using(a) { client ->
        val found = ArrayList<Video>()
        val base = root(FIRETV_MEDIA_FOLDER)
        check(client.changeWorkingDirectory(base)) { "FTP folder cannot be accessed: $base" }
        fun visit(dir: String, level: Int) {
            if (level > 14 || found.size >= maxFiles) return
            val files = client.listFiles(dir)
            for (f in files) {
                if (found.size >= maxFiles) break
                if (f.name == "." || f.name == ".." || f.name.contains('/') || f.isSymbolicLink) continue
                val path = "${dir.trimEnd('/')}/${f.name}"
                if (f.isDirectory) visit(path, level + 1)
                else if (f.isFile) VideoNames.parse(path, f.size)?.let { found.add(it) }
            }
        }
        visit(base, 0)
        found.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.title })
    }
    fun url(a: FtpAccount, path: String): String {
        fun e(part: String) = URLEncoder.encode(part, "UTF-8").replace("+", "%20")
        val full = path.split('/').joinToString("/") { e(it) }
        // URL contains credentials and must not be logged or passed to third-party APIs.
        return URI.create("ftp://${e(a.user)}:${e(a.password)}@${a.host}:${a.port}$full").toASCIIString()
    }
}
