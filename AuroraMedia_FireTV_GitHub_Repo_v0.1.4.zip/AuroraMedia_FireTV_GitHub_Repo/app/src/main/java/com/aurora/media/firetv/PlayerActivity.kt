package com.aurora.media.firetv

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import kotlin.math.max

/** Fire TV-specific player: D-pad transport controls; no touchscreen gestures or PiP. */
class PlayerActivity : Activity() {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var engine: LibVLC
    private lateinit var player: MediaPlayer
    private lateinit var surface: SurfaceView
    private lateinit var overlay: LinearLayout
    private lateinit var seek: SeekBar
    private lateinit var clock: TextView
    private lateinit var playButton: Button
    private lateinit var entry: Video
    private lateinit var mediaStore: MediaStore
    private var aspect = "Fit"
    private var buffering = false
    private var closed = false
    private var isDragging = false
    private var restored = false
    private var completed = false
    private var lastSaved = 0L
    private var length = 0L
    private var position = 0L
    private val hideControls = Runnable { if (!closed) { overlay.visibility = View.GONE; surface.requestFocus() } }
    private fun dp(n: Int) = (n * resources.displayMetrics.density + 0.5f).toInt()
    private fun fmt(ms: Long): String {
        val s = ms.coerceAtLeast(0L) / 1000
        return "%02d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60)
    }
    private fun visible() {
        overlay.visibility = View.VISIBLE
        main.removeCallbacks(hideControls)
        main.postDelayed(hideControls, 6500L)
    }
    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isFocusable = true
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(38, 51, 72))
        setOnClickListener { action(); visible() }
        setOnFocusChangeListener { v, focused ->
            v.background = GradientDrawable().apply {
                setColor(if (focused) Color.rgb(39, 97, 172) else Color.rgb(38, 51, 72))
                cornerRadius = dp(7).toFloat()
                if (focused) setStroke(dp(2), Color.rgb(147, 207, 255))
            }
            if (focused) visible()
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        val path = intent.getStringExtra("videoPath") ?: run { finish(); return }
        mediaStore = MediaStore(this)
        entry = mediaStore.library().firstOrNull { it.path == path } ?: run { finish(); return }
        val account = mediaStore.readAccount()
        if (!account.valid()) { finish(); return }

        val outer = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        surface = SurfaceView(this).apply {
            holder.setFormat(android.graphics.PixelFormat.RGBX_8888)
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { visible() }
        }
        outer.addView(surface, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(25), dp(12), dp(25), dp(16))
            setBackgroundColor(Color.argb(222, 9, 15, 26))
        }
        val heading = TextView(this).apply {
            text = entry.title + (entry.seasonEpisode?.let { " • $it" } ?: "")
            textSize = 19f; setTextColor(Color.WHITE); maxLines = 1
        }
        overlay.addView(heading)
        clock = TextView(this).apply { text = "00:00:00 / 00:00:00"; setTextColor(Color.WHITE); textSize = 15f }
        overlay.addView(clock)
        seek = SeekBar(this).apply {
            max = 1000
            isFocusable = true
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser && length > 0) clock.text = "${fmt(progress * length / 1000L)} / ${fmt(length)}"
                }
                override fun onStartTrackingTouch(bar: SeekBar?) { isDragging = true }
                override fun onStopTrackingTouch(bar: SeekBar?) {
                    if (length > 0 && player.isSeekable) player.time = (seek.progress * length / 1000L).coerceIn(0L, length)
                    isDragging = false; visible()
                }
            })
        }
        overlay.addView(seek, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32)))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun control(text: String, action: () -> Unit) {
            row.addView(button(text, action), LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        control("BACK") { finish() }
        control("-30s") { move(-30_000L) }
        playButton = button("PAUSE") { toggle() }
        row.addView(playButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        control("+30s") { move(30_000L) }
        control("RATIO") { aspectDialog() }
        control("AUDIO") { audioDialog() }
        control("SUBS") { subtitleDialog() }
        overlay.addView(row)
        outer.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        setContentView(outer)

        engine = LibVLC(applicationContext, arrayListOf("--network-caching=2000", "--no-video-title-show"))
        player = MediaPlayer(engine)
        player.vlcVout.setVideoView(surface)
        player.vlcVout.attachViews()
        player.aspectRatio = null
        player.scale = 0f // Fit = no crop or forced zoom.
        surface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) { updateWindow() }
            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { updateWindow() }
            override fun surfaceDestroyed(holder: SurfaceHolder) {}
        })
        player.setEventListener { event ->
            main.post {
                if (closed) return@post
                when (event.type) {
                    MediaPlayer.Event.Playing -> { buffering = false; playButton.text = "PAUSE" }
                    MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped -> { playButton.text = "PLAY" }
                    MediaPlayer.Event.Buffering -> { buffering = true }
                    MediaPlayer.Event.LengthChanged, MediaPlayer.Event.TimeChanged, MediaPlayer.Event.PositionChanged -> {
                        length = player.length.coerceAtLeast(0L)
                        position = player.time.coerceAtLeast(0L)
                        if (!restored && entry.savedAt > 5000 && length > entry.savedAt + 10000 && player.isSeekable) {
                            restored = true; player.time = entry.savedAt
                        }
                        if (!isDragging) {
                            clock.text = "${fmt(position)} / ${fmt(length)}"
                            seek.progress = if (length > 0) (position * 1000L / length).coerceIn(0, 1000).toInt() else 0
                        }
                        if (position - lastSaved >= 15_000L && length > 0) { saveProgress(); lastSaved = position }
                    }
                    MediaPlayer.Event.EndReached -> { completed = true; position = 0; playButton.text = "PLAY"; saveProgress() }
                    MediaPlayer.Event.EncounteredError -> {
                        showError("Cannot play this FTP video. Check the network, FTP permissions and codec support.")
                    }
                }
            }
        }
        try {
            val media = Media(engine, Uri.parse(FtpMedia.url(account, entry.path)))
            media.setHWDecoderEnabled(true, false)
            player.media = media
            media.release()
            player.play()
        } catch (e: Exception) { showError("Playback failed: ${e.message}") }
        surface.requestFocus()
        visible()
    }
    private fun showError(msg: String) { if (!isFinishing && !closed) AlertDialog.Builder(this).setTitle("Playback error").setMessage(msg).setPositiveButton("OK", null).show() }
    private fun updateWindow() {
        if (::player.isInitialized && surface.width > 0 && surface.height > 0)
            runCatching { player.vlcVout.setWindowSize(surface.width, surface.height) }
    }
    private fun move(delta: Long) {
        if (::player.isInitialized && player.isSeekable) player.time = (player.time + delta).coerceIn(0L, max(length, 0))
        visible()
    }
    private fun toggle() { if (player.isPlaying) player.pause() else player.play() }
    private fun aspectDialog() {
        val options = arrayOf("Fit", "Fill", "16:9", "4:3", "Original")
        AlertDialog.Builder(this).setTitle("Video aspect ratio").setItems(options) { _, which ->
            aspect = options[which]
            player.scale = 0f
            player.aspectRatio = when (aspect) {
                "Fill" -> "${surface.width.coerceAtLeast(1)}:${surface.height.coerceAtLeast(1)}"
                "16:9" -> "16:9"
                "4:3" -> "4:3"
                else -> null
            }
            visible()
        }.show()
    }
    private fun audioDialog() {
        val tracks = runCatching { player.audioTracks?.map { it.id to it.name }.orEmpty() }.getOrDefault(emptyList())
        if (tracks.isEmpty()) { showError("No alternative audio tracks detected."); return }
        AlertDialog.Builder(this).setTitle("Audio track").setItems(tracks.map { it.second }.toTypedArray()) { _, which ->
            player.audioTrack = tracks[which].first; visible()
        }.show()
    }
    private fun subtitleDialog() {
        val tracks = runCatching { player.spuTracks?.map { it.id to it.name }.orEmpty() }.getOrDefault(emptyList())
        if (tracks.isEmpty()) { showError("No embedded subtitle tracks detected."); return }
        AlertDialog.Builder(this).setTitle("Subtitles").setItems(tracks.map { it.second }.toTypedArray()) { _, which ->
            player.spuTrack = tracks[which].first; visible()
        }.show()
    }
    private fun saveProgress() {
        if (!::mediaStore.isInitialized || !::entry.isInitialized) return
        runCatching { mediaStore.updateProgress(entry.path, if (completed) 0L else position, length) }
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_HEADSETHOOK, KeyEvent.KEYCODE_SPACE -> { toggle(); visible(); return true }
            KeyEvent.KEYCODE_MEDIA_REWIND -> { move(-30_000L); return true }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { move(30_000L); return true }
            KeyEvent.KEYCODE_MENU -> { if (overlay.visibility == View.VISIBLE) overlay.visibility = View.GONE else visible(); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> if (overlay.visibility == View.GONE || surface.hasFocus()) { move(-10_000L); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (overlay.visibility == View.GONE || surface.hasFocus()) { move(10_000L); return true }
            KeyEvent.KEYCODE_DPAD_CENTER -> if (overlay.visibility == View.GONE || surface.hasFocus()) { toggle(); visible(); return true }
            KeyEvent.KEYCODE_DPAD_UP -> if (overlay.visibility == View.GONE) { visible(); playButton.requestFocus(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }
    override fun onPause() {
        if (::player.isInitialized && !closed) { if (player.isPlaying) player.pause(); saveProgress() }
        super.onPause()
    }
    override fun onDestroy() {
        closed = true
        main.removeCallbacksAndMessages(null)
        if (::player.isInitialized) {
            saveProgress()
            player.setEventListener(null)
            runCatching { player.stop() }
            runCatching { player.vlcVout.detachViews() }
            player.release()
        }
        if (::engine.isInitialized) engine.release()
        super.onDestroy()
    }
}
