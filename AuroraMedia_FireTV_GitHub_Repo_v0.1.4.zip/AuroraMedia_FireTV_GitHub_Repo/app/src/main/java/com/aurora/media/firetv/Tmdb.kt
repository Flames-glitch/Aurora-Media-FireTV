package com.aurora.media.firetv

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.ExecutorService
import org.json.JSONObject

object Tmdb {
    // TMDb v3 search; key is embedded at the app owner's explicit request.
    fun enrich(item: Video): Video {
        if (item.tmdbId > 0 || !item.poster.isNullOrBlank()) return item
        val kind = if (item.tv) "tv" else "movie"
        val q = URLEncoder.encode(item.title, "UTF-8")
        val year = if (!item.tv && item.year != null) "&year=${item.year}" else ""
        val url = "https://api.themoviedb.org/3/search/$kind?api_key=${BuildConfig.TMDB_API_KEY}&query=$q$year&include_adult=false"
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 6000
        conn.readTimeout = 6000
        conn.setRequestProperty("Accept", "application/json")
        return try {
            check(conn.responseCode == 200) { "TMDb HTTP ${conn.responseCode}" }
            val results = JSONObject(conn.inputStream.bufferedReader().use { it.readText() }).getJSONArray("results")
            if (results.length() == 0) item else {
                val first = (0 until results.length()).map { results.getJSONObject(it) }
                    .firstOrNull { it.optString("poster_path").startsWith("/") }
                    ?: results.getJSONObject(0)
                val poster = first.optString("poster_path")
                item.copy(
                    poster = if (poster.startsWith("/")) "https://image.tmdb.org/t/p/w342$poster" else null,
                    description = first.optString("overview").takeIf { it.isNotBlank() },
                    tmdbId = first.optInt("id", 0)
                )
            }
        } finally { conn.disconnect() }
    }
}

/** Small RAM+disk poster cache designed for older Fire TV Sticks. */
class PosterLoader(private val dir: File, private val pool: ExecutorService) {
    private val main = Handler(Looper.getMainLooper())
    private val cache = object : LruCache<String, Bitmap>(10 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = (value.byteCount / 1024).coerceAtLeast(1)
    }
    init { dir.mkdirs() }
    fun show(image: ImageView, url: String?) {
        image.tag = url
        image.setImageDrawable(null)
        if (url == null) return
        synchronized(cache) { cache.get(url) }?.let { image.setImageBitmap(it); return }
        pool.execute {
            val bitmap = runCatching { load(url) }.getOrNull()
            if (bitmap != null) synchronized(cache) { cache.put(url, bitmap) }
            main.post { if (image.tag == url && bitmap != null) image.setImageBitmap(bitmap) }
        }
    }
    private fun load(url: String): Bitmap? {
        val hash = MessageDigest.getInstance("SHA-256").digest(url.toByteArray())
            .joinToString("") { "%02x".format(it) }.take(32)
        val file = File(dir, "$hash.jpg")
        if (!file.exists()) {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 6_000; conn.readTimeout = 6_000
            try {
                if (conn.responseCode != 200) return null
                val tmp = File(dir, "$hash.tmp")
                conn.inputStream.use { input ->
                    FileOutputStream(tmp).use { output ->
                        val buf = ByteArray(8192)
                        var bytes = 0L
                        while (true) {
                            val count = input.read(buf)
                            if (count <= 0) break
                            bytes += count
                            if (bytes > 4_000_000L) error("Poster exceeds 4 MB")
                            output.write(buf, 0, count)
                        }
                    }
                }
                if (!tmp.renameTo(file)) { tmp.delete(); return null }
            } finally { conn.disconnect() }
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 320 || bounds.outHeight / sample > 440) sample *= 2
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        })
    }
}
