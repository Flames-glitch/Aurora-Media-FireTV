# Aurora Media Fire TV v0.1.5

Lightweight **Fire OS 5 / Android 5.1 (API 22)** native television player for your personal FTP media library. Remote-operated, no touchscreen gestures or picture-in-picture.

## What's new in v0.1.5

- Cinematic dark home interface with a featured video, poster grid, TMDb title/description, and Continue Watching cards populated from scanned FTP files.
- Native-drawn icons (no font icon dependencies), blue focus rings for the Fire TV remote.
- Transparent-to-dark gradient VLC-like overlay in the player that automatically hides after five seconds.
- Four video-player controls: **−10 seconds**, **Play/Pause**, **+10 seconds**, and a combined **Audio & Subtitles** menu with two tabs.
- Native remote **Back** closes Audio & Subtitles first; otherwise it returns to the movie library and stops playback. Library Back asks to exit.
- No aspect-ratio button: LibVLC displays the source aspect ratio automatically, scaled to fit without cropping.
- FTP settings, passwords, TMDb API configuration, and saved playback progress are retained when installing over the prior edition (if the signing signature matches).

## Existing configuration

- Default editable FTP IP: `192.168.1.254`; default FTP port: 21.
- Media folder: **`/usb1_1/movies`**, fixed by project configuration.
- Password is masked in the app after typing, but the native Fire TV keyboard is controlled by the system. Saved FTP credentials aren't encrypted on Fire OS 5.
- FTP only, with recursive directory discovery, Apache Commons Net 3.8.0, LibVLC 3.5.1, and TMDb lookups.
- Embedded TMDb API key is not secret in a distributable Android APK.

## How to build (Android phone / GitHub)

1. Upload `AuroraMedia_FireTV_GitHub_Repo_v0.1.5.zip` to the **repository root**, without extracting it.
2. Keep `.github/workflows/build-firetv.yml` as the active GitHub Actions workflow.
3. The workflow selects the highest numbered source ZIP, extracts the `AuroraMedia_FireTV_GitHub_Repo` directory, and runs `gradle :app:assembleDebug` with Android SDK 35, Java 17 and Gradle 8.9.
4. Download `AuroraMedia-FireTV-APK` from the completed workflow's artifacts and sideload it to Fire TV.

**Status:** Source/ZIP checks passed. APK compilation and device tests must be completed on GitHub and the user's Fire OS 5 stick. The appearance will be native Android and may differ from the earlier conceptual image mockups.
