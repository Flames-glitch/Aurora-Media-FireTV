package com.aurora.media.firetv

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import android.view.inputmethod.EditorInfo
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.text.TextUtils
import android.widget.HorizontalScrollView
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.util.concurrent.Executors

/** Native TV/D-pad interface: no Compose or AndroidX, compatible with Android API 22. */
class MainActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private val images = Executors.newFixedThreadPool(2)
    private lateinit var store: MediaStore
    private lateinit var posters: PosterLoader
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var grid: GridView
    private lateinit var featuredTitle: TextView
    private lateinit var featuredMeta: TextView
    private lateinit var featuredDescription: TextView
    private lateinit var featuredPoster: ImageView
    private lateinit var featuredPlay: Button
    private var featuredMovie: Video? = null
    private var setupVisible = false
    private var videos: List<Video> = emptyList()
    private var columns = 4
    private var cellWidth = 160
    private var alive = true

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density + 0.5f).toInt()
    private fun bg(color: Int, stroke: Int = Color.TRANSPARENT, r: Int = 10): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(r).toFloat()
            if (stroke != Color.TRANSPARENT) setStroke(dp(3), stroke)
        }
    private fun label(text: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER_VERTICAL
    }
    private fun button(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        isFocusable = true
        setOnClickListener { click() }
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(34, 51, 74))
        setOnFocusChangeListener { v, focused ->
            v.background = bg(if (focused) Color.rgb(36, 76, 132) else Color.rgb(34, 51, 74),
                if (focused) Color.rgb(120, 190, 255) else Color.TRANSPARENT)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        store = MediaStore(this)
        posters = PosterLoader(File(cacheDir, "posters"), images)
        val a = store.readAccount()
        if (!a.valid()) showSetup(a) else {
            showLibrary()
            rescan() // Show cached posters first, then discover newly added FTP files.
        }
    }
    private fun container(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 13, 24))
            setPadding(dp(28), dp(12), dp(28), dp(12))
        }
        setContentView(root)
        return root
    }
    private fun field(hint: String, value: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText =
        EditText(this).apply {
            this.hint = hint
            setText(value)
            inputType = type
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setSelectAllOnFocus(true)
            isFocusableInTouchMode = true
        }

    private fun showSetup(account: FtpAccount) {
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val pane = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(70), dp(14), dp(70), dp(20))
            setBackgroundColor(Color.rgb(8, 13, 24))
        }
        scroll.addView(pane)
        setContentView(scroll)
        setupVisible = true
        pane.addView(label("AURORA MEDIA  /  FIRE TV", 27f).apply { setTypeface(null, Typeface.BOLD) })
        pane.addView(label("One-time FTP setup. Use your remote to select each field.", 15f, Color.LTGRAY))
        val host = field("FTP server IP / hostname", account.host.ifBlank { FIRETV_DEFAULT_FTP_HOST })
        val port = field("Port", account.port.toString(), InputType.TYPE_CLASS_NUMBER)
        val user = field("Username", account.user)
        val pass = field("Password", account.password,
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS).apply {
            // Always draw bullets, including when text is restored after Fire TV's on-screen keyboard closes.
            transformationMethod = PasswordTransformationMethod.getInstance()
            // Ask the keyboard to treat this as a sensitive field and avoid full-screen text extraction.
            imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_ACTION_DONE
            setSelectAllOnFocus(false)
        }
        for (view in listOf(host, port, user, pass)) {
            pane.addView(view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)))
        }
        pane.addView(label("Media folder (fixed): /$FIRETV_MEDIA_FOLDER", 15f, Color.LTGRAY))
        val info = label("FTP credentials are stored privately on this older device, but not encrypted. Use a trusted home network.", 13f, Color.LTGRAY)
        pane.addView(info)
        val connect = button("CONNECT & SCAN") {
            val a = FtpAccount(host.text.toString().trim(), port.text.toString().toIntOrNull() ?: 21,
                user.text.toString(), pass.text.toString(), FIRETV_MEDIA_FOLDER)
            if (!a.valid()) { info.text = "Enter a valid host, username and port."; return@button }
            info.text = "Checking FTP connection…"
            io.execute {
                val result = runCatching { FtpMedia.test(a) }
                runOnUiThread {
                    if (!alive) return@runOnUiThread
                    result.onSuccess { store.saveAccount(a); showLibrary(); rescan() }
                        .onFailure { info.text = "Connection failed: ${it.message}" }
                }
            }
        }
        pane.addView(connect, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(55)))
        connect.requestFocus()
    }

    private fun showLibrary() {
        setupVisible = false
        videos = store.library()
        val compact = resources.displayMetrics.heightPixels / resources.displayMetrics.density < 620f
        val canvas = container().apply {
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setBackgroundColor(Color.rgb(5, 10, 19))
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        canvas.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        // Compact remote-friendly navigation, not a heavyweight Leanback dependency.
        val rail = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(14), dp(8), dp(10))
        }
        val nav = fun(title: String, action: () -> Unit): TextView = TextView(this).apply {
            text = title
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(203, 216, 240))
            isFocusable = true
            background = bg(Color.rgb(17, 29, 48), r = 10)
            setOnClickListener { action() }
            setOnFocusChangeListener { v, focused ->
                v.background = bg(if (focused) Color.rgb(14, 78, 166) else Color.rgb(17, 29, 48),
                    if (focused) Color.rgb(49, 155, 255) else Color.TRANSPARENT)
            }
        }
        rail.addView(label("◆", 30f, Color.rgb(50, 158, 255)).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(-1, dp(59)))
        rail.addView(nav("HOME") { grid.requestFocus(); grid.setSelection(0) },
            LinearLayout.LayoutParams(-1, dp(62)).apply { bottomMargin = dp(10) })
        rail.addView(nav("LIBRARY") { grid.requestFocus() },
            LinearLayout.LayoutParams(-1, dp(62)).apply { bottomMargin = dp(10) })
        rail.addView(nav("FTP") { showSetup(store.readAccount()) },
            LinearLayout.LayoutParams(-1, dp(62)))
        content.addView(rail, LinearLayout.LayoutParams(dp(93), -1))

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(1), dp(14), dp(2))
        }
        content.addView(page, LinearLayout.LayoutParams(0, -1, 1f))
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("AURORA  MEDIA", 22f).apply {
            setTypeface(null, Typeface.BOLD); letterSpacing = 0.13f
        }, LinearLayout.LayoutParams(0, dp(52), 1f))
        val reload = button("⟳  Rescan") { rescan() }
        header.addView(reload, LinearLayout.LayoutParams(dp(132), dp(40)))
        page.addView(header, LinearLayout.LayoutParams(-1, dp(if (compact) 42 else 52)))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(26), dp(12), dp(18), dp(12))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(13, 25, 47), Color.rgb(12, 28, 53), Color.rgb(7, 13, 24))).apply {
                cornerRadius = dp(16).toFloat()
            }
        }
        val heroText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heroText.addView(label("FEATURED FROM YOUR LIBRARY", 12f, Color.rgb(86, 165, 255)).apply {
            letterSpacing = 0.16f
        }, LinearLayout.LayoutParams(-1, dp(if (compact) 22 else 25)))
        featuredTitle = label("Aurora Media", if (compact) 22f else 28f).apply {
            setTypeface(null, Typeface.BOLD)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        heroText.addView(featuredTitle, LinearLayout.LayoutParams(-1, dp(if (compact) 50 else 77)))
        featuredMeta = label("Your FTP video collection", 15f, Color.rgb(164, 186, 213))
        heroText.addView(featuredMeta, LinearLayout.LayoutParams(-1, dp(if (compact) 22 else 28)))
        featuredDescription = label("Choose a movie below to see its details.", 14f, Color.rgb(211, 222, 239)).apply {
            maxLines = 2; ellipsize = TextUtils.TruncateAt.END
        }
        heroText.addView(featuredDescription, LinearLayout.LayoutParams(-1, dp(if (compact) 30 else 49)))
        featuredPlay = button("▶  PLAY") {
            featuredMovie?.let { launchPlayer(it) }
        }.apply { textSize = 16f }
        heroText.addView(featuredPlay, LinearLayout.LayoutParams(dp(139), dp(if (compact) 37 else 42)))
        hero.addView(heroText, LinearLayout.LayoutParams(0, -1, 1f))
        featuredPoster = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = bg(Color.rgb(29, 43, 66), r = 9)
        }
        hero.addView(featuredPoster, LinearLayout.LayoutParams(dp(if (compact) 115 else 146), dp(if (compact) 157 else 205)).apply {
            leftMargin = dp(20)
        })
        page.addView(hero, LinearLayout.LayoutParams(-1, dp(if (compact) 185 else 235)))

        status = label("${videos.size} videos  •  Press Select to see details", 13f,
            Color.rgb(137, 160, 193))
        page.addView(status, LinearLayout.LayoutParams(-1, dp(if (compact) 26 else 33)))

        // Recently played items remain accessible without a separate submenu.
        val continuing = videos.filter { it.savedAt > 0L }.take(5)
        if (continuing.isNotEmpty() && !compact) {
            page.addView(label("Continue Watching", 19f).apply { setTypeface(null, Typeface.BOLD) },
                LinearLayout.LayoutParams(-1, dp(33)))
            val scroller = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
            }
            val cards = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            scroller.addView(cards)
            for (movie in continuing) {
                val tile = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(5), dp(5), dp(8), dp(5))
                    background = bg(Color.rgb(19, 31, 50))
                    isFocusable = true
                    setOnClickListener { launchPlayer(movie) }
                    setOnFocusChangeListener { v, focus -> v.background = bg(
                        if (focus) Color.rgb(15, 68, 126) else Color.rgb(19, 31, 50),
                        if (focus) Color.rgb(36, 151, 255) else Color.TRANSPARENT) }
                }
                val art = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
                tile.addView(art, LinearLayout.LayoutParams(dp(52), dp(80)))
                posters.show(art, movie.poster)
                val copy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                copy.addView(label(movie.title, 14f).apply {
                    setTypeface(null, Typeface.BOLD); maxLines = 2
                }, LinearLayout.LayoutParams(-1, dp(52)))
                val pct = if (movie.duration > 0L) movie.savedAt * 100 / movie.duration else 0L
                copy.addView(label("${pct.coerceIn(0L, 100L)}% watched", 12f,
                    Color.rgb(112, 170, 232)))
                tile.addView(copy, LinearLayout.LayoutParams(dp(139), -1).apply { leftMargin = dp(9) })
                cards.addView(tile, LinearLayout.LayoutParams(dp(220), dp(90)).apply { rightMargin = dp(12) })
            }
            page.addView(scroller, LinearLayout.LayoutParams(-1, dp(96)))
        }
        page.addView(label("Recently Added", 20f).apply { setTypeface(null, Typeface.BOLD) },
            LinearLayout.LayoutParams(-1, dp(if (compact) 29 else 37)))
        val width = resources.displayMetrics.widthPixels
        columns = ((width - dp(147)) / dp(172)).coerceIn(3, 7)
        cellWidth = ((width - dp(150)) / columns) - dp(10)
        grid = GridView(this).apply {
            numColumns = columns
            horizontalSpacing = dp(10)
            verticalSpacing = dp(13)
            stretchMode = GridView.NO_STRETCH
            columnWidth = cellWidth
            clipToPadding = false
            setPadding(dp(4), dp(6), dp(4), dp(8))
            isFocusable = true
            isFocusableInTouchMode = true
            selector = bg(Color.TRANSPARENT, Color.rgb(43, 152, 255), 9)
        }
        grid.adapter = MovieAdapter()
        grid.onItemClickListener = android.widget.AdapterView.OnItemClickListener { _, _, position, _ ->
            openDetails(videos[position])
        }
        grid.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                videos.getOrNull(position)?.let { updateFeatured(it) }
                grid.invalidateViews()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        page.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        page.addView(label("Metadata provided by TMDb   •   Your movies stay on your FTP server", 11f,
            Color.rgb(100, 121, 147)), LinearLayout.LayoutParams(-1, dp(if (compact) 16 else 23)))
        videos.firstOrNull()?.let { updateFeatured(it) }
        if (videos.isNotEmpty()) grid.requestFocus() else reload.requestFocus()
    }
    private fun updateFeatured(movie: Video) {
        featuredMovie = movie
        featuredTitle.text = movie.title
        featuredMeta.text = buildString {
            movie.year?.let { append("$it   •   ") }
            append(if (movie.tv) "TV episode" else "Movie")
            movie.seasonEpisode?.let { append("   •   $it") }
        }
        featuredDescription.text = movie.description?.takeIf { it.isNotBlank() }
            ?: "Select to play from your personal media library"
        posters.show(featuredPoster, movie.poster)
    }
    private inner class MovieAdapter : BaseAdapter() {
        override fun getCount() = videos.size
        override fun getItem(position: Int): Any = videos[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val item = videos[position]
            val selected = ::grid.isInitialized && grid.selectedItemPosition == position
            val column = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                background = bg(if (selected) Color.rgb(19, 49, 88) else Color.rgb(15, 25, 43),
                    if (selected) Color.rgb(37, 153, 255) else Color.TRANSPARENT, 10)
                setPadding(dp(5), dp(5), dp(5), dp(5))
            }
            val poster = ImageView(this@MainActivity).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.rgb(30, 45, 68))
            }
            column.addView(poster, LinearLayout.LayoutParams(-1, (cellWidth * 1.22f).toInt()))
            posters.show(poster, item.poster)
            column.addView(label(item.title + (item.seasonEpisode?.let { "  $it" } ?: ""), 13f).apply {
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setTypeface(null, Typeface.BOLD)
            }, LinearLayout.LayoutParams(-1, dp(39)))
            return column
        }
    }
    private fun launchPlayer(movie: Video) {
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("videoPath", movie.path))
    }
    private fun openDetails(video: Video) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(16), dp(16), dp(14))
            setBackgroundColor(Color.rgb(12, 20, 34))
        }
        val art = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        card.addView(art, LinearLayout.LayoutParams(dp(123), dp(184)))
        posters.show(art, video.poster)
        val copy = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), 0, 0, 0)
        }
        copy.addView(label(video.title, 23f).apply {
            setTypeface(null, Typeface.BOLD); maxLines = 2
        })
        copy.addView(label(buildString {
            video.year?.let { append("$it   •   ") }
            append(if (video.tv) "TV Episode" else "Movie")
            video.seasonEpisode?.let { append("   •   $it") }
        }, 14f, Color.rgb(139, 183, 239)))
        copy.addView(label(video.description ?: "No description available for this video.", 15f,
            Color.rgb(208, 220, 238)).apply { maxLines = 6 }, LinearLayout.LayoutParams(-1, 0, 1f))
        if (video.savedAt > 0) copy.addView(label("Continue where you left off", 13f,
            Color.rgb(62, 160, 255)))
        card.addView(copy, LinearLayout.LayoutParams(dp(360), dp(184)))
        val dialog = AlertDialog.Builder(this).setView(card)
            .setPositiveButton("▶  PLAY") { _, _ -> launchPlayer(video) }
            .setNegativeButton("CLOSE", null).create()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).requestFocus()
    }
    private fun rescan() {
        val a = store.readAccount()
        if (!a.valid()) { showSetup(a); return }
        status.text = "Scanning FTP folders…"
        io.execute {
            try {
                val scanned = FtpMedia.scan(a)
                val old = store.library().associateBy { it.path }
                val updated = scanned.map { item ->
                    old[item.path]?.takeIf { it.size == item.size }?.copy(title = item.title, filename = item.filename) ?: item
                }.toMutableList()
                store.save(updated)
                runOnUiThread {
                    if (alive) { videos = updated.toList(); grid.adapter = MovieAdapter(); status.text = "Found ${videos.size} videos • Loading posters…" }
                }
                var failures = 0
                for (i in updated.indices) {
                    if (Thread.currentThread().isInterrupted) break
                    if (updated[i].tmdbId != 0 || !updated[i].poster.isNullOrEmpty()) continue
                    updated[i] = try { Tmdb.enrich(updated[i]) } catch (_: Exception) { failures++; updated[i] }
                    if (i % 6 == 0 || i == updated.lastIndex) {
                        store.save(updated)
                        val snapshot = updated.toList()
                        runOnUiThread {
                            if (alive) {
                                val selected = grid.selectedItemPosition.coerceAtLeast(0)
                                videos = snapshot
                                grid.adapter = MovieAdapter()
                                if (snapshot.isNotEmpty()) {
                                    grid.setSelection(selected.coerceAtMost(snapshot.lastIndex))
                                    grid.requestFocus()
                                }
                                status.text = "${snapshot.size} videos • Metadata ${i+1}/${snapshot.size}" + if (failures > 0) " • $failures lookups failed" else ""
                            }
                        }
                    }
                }
                store.save(updated)
                runOnUiThread { if (alive) status.text = "${updated.size} videos • Press Select to play • Menu to rescan" }
            } catch (e: Exception) {
                runOnUiThread { if (alive) status.text = "FTP scan failed: ${e.message}" }
            }
        }
    }
    override fun onBackPressed() {
        if (setupVisible && store.readAccount().valid()) { showLibrary(); return }
        AlertDialog.Builder(this)
            .setTitle("Exit Aurora Media?")
            .setMessage("Return to your Fire TV home screen?")
            .setPositiveButton("EXIT") { _, _ -> finish() }
            .setNegativeButton("CANCEL", null).show()
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU && ::status.isInitialized) { rescan(); return true }
        return super.onKeyDown(keyCode, event)
    }
    override fun onResume() {
        super.onResume()
        if (::grid.isInitialized && ::status.isInitialized) {
            val saved = store.library()
            if (saved.isNotEmpty() && saved.size == videos.size) { videos = saved; grid.adapter = MovieAdapter() }
        }
    }
    override fun onDestroy() {
        alive = false
        io.shutdownNow(); images.shutdownNow()
        super.onDestroy()
    }
}
