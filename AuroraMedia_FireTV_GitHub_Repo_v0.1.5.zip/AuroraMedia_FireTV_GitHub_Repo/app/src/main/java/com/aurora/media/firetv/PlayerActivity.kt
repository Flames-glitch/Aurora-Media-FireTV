package com.aurora.media.firetv

import android.app.Activity
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import kotlin.math.max

/** Android 5.1-compatible cinematic player. Native remote, no PiP or touchscreen gestures. */
class PlayerActivity : Activity() {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var engine: LibVLC
    private lateinit var player: MediaPlayer
    private lateinit var surface: SurfaceView
    private lateinit var frame: FrameLayout
    private lateinit var overlay: LinearLayout
    private lateinit var seek: SeekBar
    private lateinit var clock: TextView
    private lateinit var playControl: IconControl
    private lateinit var entry: Video
    private lateinit var mediaStore: MediaStore
    private var settingsPanel: LinearLayout? = null
    private var showingSubtitles = false
    private var closed = false
    private var isDragging = false
    private var restored = false
    private var completed = false
    private var lastSaved = 0L
    private var length = 0L
    private var position = 0L
    private val blue = Color.rgb(27, 136, 255)
    private val hideControls = Runnable {
        if (!closed && settingsPanel == null && ::overlay.isInitialized) {
            overlay.visibility = View.GONE
            surface.requestFocus()
        }
    }
    private fun dp(n: Int) = (n * resources.displayMetrics.density + 0.5f).toInt()
    private fun fmt(ms: Long): String {
        val s = ms.coerceAtLeast(0L) / 1000L
        return "%02d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60)
    }
    private fun reveal(focus: Boolean = false) {
        overlay.visibility = View.VISIBLE
        main.removeCallbacks(hideControls)
        if (settingsPanel == null) main.postDelayed(hideControls, 5000L)
        if (focus) playControl.requestFocus()
    }
    private fun panelShape(focused: Boolean): GradientDrawable = GradientDrawable().apply {
        setColor(if (focused) Color.rgb(19, 79, 159) else Color.rgb(29, 40, 61))
        cornerRadius = dp(11).toFloat()
        if (focused) setStroke(dp(2), Color.rgb(95, 193, 255))
    }
    private inner class IconControl(private var kind: String, description: String, val perform: () -> Unit) : View(this@PlayerActivity) {
        private val brush = Paint(Paint.ANTI_ALIAS_FLAG)
        init {
            isFocusable = true
            contentDescription = description
            setOnClickListener { perform(); if (settingsPanel == null) reveal() }
            setOnFocusChangeListener { _, focused -> invalidate(); if (focused) reveal() }
        }
        fun setKind(value: String) { kind = value; invalidate() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val size = minOf(width, height).toFloat()
            val cx = width / 2f
            val cy = height / 2f
            canvas.save()
            canvas.translate(cx - size / 2f, cy - size / 2f)
            canvas.scale(size / 100f, size / 100f)
            brush.style = Paint.Style.FILL
            brush.color = if (hasFocus()) Color.rgb(13, 70, 145) else Color.argb(175, 22, 33, 51)
            canvas.drawCircle(50f, 50f, 46f, brush)
            if (hasFocus()) {
                brush.style = Paint.Style.STROKE
                brush.strokeWidth = 3f
                brush.color = Color.rgb(29, 155, 255)
                canvas.drawCircle(50f, 50f, 45f, brush)
                brush.style = Paint.Style.FILL
            }
            brush.color = Color.WHITE
            when (kind) {
                "play" -> {
                    val path = Path().apply { moveTo(40f, 31f); lineTo(40f, 69f); lineTo(70f, 50f); close() }
                    canvas.drawPath(path, brush)
                }
                "pause" -> {
                    canvas.drawRoundRect(RectF(35f, 31f, 44f, 69f), 2f, 2f, brush)
                    canvas.drawRoundRect(RectF(55f, 31f, 64f, 69f), 2f, 2f, brush)
                }
                "back10", "forward10" -> {
                    brush.style = Paint.Style.STROKE; brush.strokeWidth = 5f; brush.strokeCap = Paint.Cap.ROUND
                    val backward = kind == "back10"
                    canvas.drawArc(RectF(29f, 27f, 72f, 72f), if (backward) 208f else -25f,
                        if (backward) 295f else 295f, false, brush)
                    brush.style = Paint.Style.FILL
                    val arrow = Path()
                    if (backward) {
                        arrow.moveTo(24f, 35f); arrow.lineTo(43f, 32f); arrow.lineTo(35f, 48f)
                    } else {
                        arrow.moveTo(76f, 35f); arrow.lineTo(57f, 32f); arrow.lineTo(65f, 48f)
                    }
                    arrow.close(); canvas.drawPath(arrow, brush)
                    brush.textAlign = Paint.Align.CENTER
                    brush.typeface = Typeface.create("sans-serif", Typeface.BOLD)
                    brush.textSize = 23f
                    canvas.drawText("10", 50f, 59f, brush)
                }
                "settings" -> {
                    brush.style = Paint.Style.STROKE; brush.strokeCap = Paint.Cap.ROUND; brush.strokeWidth = 5f
                    for (y in listOf(33f, 50f, 67f)) canvas.drawLine(29f, y, 71f, y, brush)
                    brush.style = Paint.Style.FILL
                    for ((x, y) in listOf(43f to 33f, 61f to 50f, 48f to 67f)) {
                        brush.color = Color.rgb(22, 36, 60)
                        canvas.drawCircle(x, y, 8f, brush)
                        brush.color = Color.WHITE
                        canvas.drawCircle(x, y, 5f, brush)
                    }
                }
            }
            canvas.restore()
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        val path = intent.getStringExtra("videoPath") ?: run { finish(); return }
        mediaStore = MediaStore(this)
        entry = mediaStore.library().firstOrNull { it.path == path } ?: run { finish(); return }
        val account = mediaStore.readAccount()
        if (!account.valid()) { finish(); return }

        frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        surface = SurfaceView(this).apply {
            holder.setFormat(android.graphics.PixelFormat.RGBX_8888)
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { reveal(true) }
        }
        frame.addView(surface, FrameLayout.LayoutParams(-1, -1))
        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(42), dp(58), dp(42), dp(23))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(
                Color.TRANSPARENT, Color.argb(145, 4, 9, 19), Color.argb(245, 4, 9, 19)))
        }
        val title = TextView(this).apply {
            text = entry.title + (entry.seasonEpisode?.let { "  •  $it" } ?: "")
            textSize = 24f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
            setSingleLine(true); ellipsize = TextUtils.TruncateAt.END
        }
        overlay.addView(title, LinearLayout.LayoutParams(-1, dp(36)))
        clock = TextView(this).apply {
            text = "00:00:00 / 00:00:00"; textSize = 15f; setTextColor(Color.rgb(185, 199, 222))
        }
        overlay.addView(clock)
        seek = SeekBar(this).apply {
            max = 1000
            isFocusable = true
            progressTintList = ColorStateList.valueOf(blue)
            progressBackgroundTintList = ColorStateList.valueOf(Color.rgb(92, 105, 125))
            thumbTintList = ColorStateList.valueOf(Color.rgb(49, 160, 255))
            setOnFocusChangeListener { _, focused -> if (focused) reveal() }
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser && length > 0) clock.text = "${fmt(progress * length / 1000L)} / ${fmt(length)}"
                }
                override fun onStartTrackingTouch(bar: SeekBar?) { isDragging = true }
                override fun onStopTrackingTouch(bar: SeekBar?) {
                    if (length > 0 && player.isSeekable) player.time = (seek.progress * length / 1000L).coerceIn(0L, length)
                    isDragging = false; reveal()
                }
            })
        }
        overlay.addView(seek, LinearLayout.LayoutParams(-1, dp(33)))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun put(control: IconControl) {
            actions.addView(control, LinearLayout.LayoutParams(dp(78), dp(72)).apply {
                leftMargin = dp(14); rightMargin = dp(14)
            })
        }
        put(IconControl("back10", "Rewind ten seconds") { move(-10_000L) })
        playControl = IconControl("pause", "Play or pause") { toggle() }
        put(playControl)
        put(IconControl("forward10", "Forward ten seconds") { move(10_000L) })
        put(IconControl("settings", "Audio and subtitles") { openSettings(false) })
        overlay.addView(actions)
        frame.addView(overlay, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(frame)

        engine = LibVLC(applicationContext, arrayListOf("--network-caching=2000", "--no-video-title-show"))
        player = MediaPlayer(engine)
        player.vlcVout.setVideoView(surface)
        player.vlcVout.attachViews()
        player.aspectRatio = null
        player.scale = 0f // Preserve video proportions; fit within TV, never crop.
        surface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) { updateWindow() }
            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { updateWindow() }
            override fun surfaceDestroyed(holder: SurfaceHolder) {}
        })
        player.setEventListener { event ->
            main.post {
                if (closed) return@post
                when (event.type) {
                    MediaPlayer.Event.Playing -> { playControl.setKind("pause") }
                    MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped -> { playControl.setKind("play") }
                    MediaPlayer.Event.LengthChanged, MediaPlayer.Event.TimeChanged, MediaPlayer.Event.PositionChanged -> {
                        length = player.length.coerceAtLeast(0L)
                        position = player.time.coerceAtLeast(0L)
                        if (!restored && entry.savedAt > 5000L && length > entry.savedAt + 10000L && player.isSeekable) {
                            restored = true; player.time = entry.savedAt
                        }
                        if (!isDragging) {
                            clock.text = "${fmt(position)} / ${fmt(length)}"
                            seek.progress = if (length > 0L) (position * 1000L / length).coerceIn(0L, 1000L).toInt() else 0
                        }
                        if (position - lastSaved >= 15000L && length > 0L) { saveProgress(); lastSaved = position }
                    }
                    MediaPlayer.Event.EndReached -> { completed = true; position = 0L; playControl.setKind("play"); saveProgress() }
                    MediaPlayer.Event.EncounteredError -> showError("Unable to play this FTP video. Check network access and codec support.")
                }
            }
        }
        try {
            val media = Media(engine, Uri.parse(FtpMedia.url(account, entry.path)))
            media.setHWDecoderEnabled(true, false)
            player.media = media
            media.release()
            player.play()
        } catch (e: Exception) { showError("Playback failed: ${e.message}") }
        reveal(true)
    }
    private fun showError(message: String) {
        if (!closed && !isFinishing) AlertDialog.Builder(this).setTitle("Aurora Media").setMessage(message)
            .setPositiveButton("OK", null).show()
    }
    private fun updateWindow() {
        if (::player.isInitialized && surface.width > 0 && surface.height > 0) {
            runCatching { player.vlcVout.setWindowSize(surface.width, surface.height) }
        }
    }
    private fun move(delta: Long) {
        if (::player.isInitialized && player.isSeekable) {
            val end = if (length > 0L) length else Long.MAX_VALUE
            player.time = (player.time + delta).coerceIn(0L, end)
        }
        reveal()
    }
    private fun toggle() {
        if (::player.isInitialized) {
            if (player.isPlaying) player.pause() else player.play()
        }
    }
    private fun openSettings(subtitles: Boolean) {
        if (settingsPanel != null) closeSettings()
        showingSubtitles = subtitles
        main.removeCallbacks(hideControls)
        overlay.visibility = View.GONE
        val side = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(20))
            background = GradientDrawable().apply {
                setColor(Color.argb(246, 11, 19, 34))
                cornerRadius = dp(17).toFloat()
                setStroke(dp(1), Color.rgb(39, 64, 102))
            }
            isFocusable = false
        }
        settingsPanel = side
        frame.addView(side, FrameLayout.LayoutParams(dp(360), -1, Gravity.RIGHT).apply {
            topMargin = dp(10); rightMargin = dp(10); bottomMargin = dp(10)
        })
        renderSettings()
    }
    private fun menuOption(text: String, checked: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = (if (checked) "✓  " else "     ") + text
        textSize = 17f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(16), 0, dp(10), 0)
        background = panelShape(false)
        isFocusable = true
        setOnClickListener { onClick() }
        setOnFocusChangeListener { view, focused -> view.background = panelShape(focused) }
    }
    private fun renderSettings() {
        val side = settingsPanel ?: return
        side.removeAllViews()
        side.addView(TextView(this).apply {
            text = "Audio & Subtitles"; textSize = 24f; setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        }, LinearLayout.LayoutParams(-1, dp(62)))
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun tab(label: String, selected: Boolean, action: () -> Unit): TextView = menuOption(label, selected, action).apply {
            gravity = Gravity.CENTER
            textSize = 17f
        }
        val audioTab = tab("Audio", !showingSubtitles) { showingSubtitles = false; renderSettings() }
        val subtitleTab = tab("Subtitles", showingSubtitles) { showingSubtitles = true; renderSettings() }
        tabs.addView(audioTab, LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(6) })
        tabs.addView(subtitleTab, LinearLayout.LayoutParams(0, dp(48), 1f))
        side.addView(tabs)
        side.addView(TextView(this).apply {
            text = if (showingSubtitles) "SUBTITLE TRACK" else "AUDIO TRACK"
            textSize = 12f; setTextColor(Color.rgb(146, 173, 207)); letterSpacing = 0.12f
            gravity = Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(-1, dp(55)))
        val tracks = if (showingSubtitles) {
            val available = runCatching { player.spuTracks?.map { it.id to it.name }.orEmpty() }
                .getOrDefault(emptyList())
            if (available.any { it.first == -1 }) {
                available.map { if (it.first == -1) -1 to "Off" else it }
            } else {
                listOf(-1 to "Off") + available
            }
        } else {
            runCatching { player.audioTracks?.map { it.id to it.name }.orEmpty() }.getOrDefault(emptyList())
        }
        val selected = if (showingSubtitles) player.spuTrack else player.audioTrack
        var firstOption: TextView? = null
        val options = android.widget.ScrollView(this).apply { isFillViewport = false }
        val optionsColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        options.addView(optionsColumn)
        side.addView(options, LinearLayout.LayoutParams(-1, 0, 1f))
        if (tracks.isEmpty()) {
            optionsColumn.addView(TextView(this).apply {
                text = if (showingSubtitles) "No embedded subtitle tracks detected." else "No alternative audio tracks detected."
                textSize = 16f; setTextColor(Color.LTGRAY)
            })
        } else {
            for ((id, title) in tracks) {
                val option = menuOption(title ?: "Track $id", id == selected) {
                    if (showingSubtitles) player.spuTrack = id else player.audioTrack = id
                    renderSettings()
                }
                optionsColumn.addView(option, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(6) })
                if (firstOption == null || id == selected) firstOption = option
            }
        }
        side.addView(TextView(this).apply {
            text = "Press Back on your remote to return to the video"
            textSize = 13f; setTextColor(Color.rgb(150, 171, 199))
        }, LinearLayout.LayoutParams(-1, dp(48)))
        (firstOption ?: if (showingSubtitles) subtitleTab else audioTab).requestFocus()
    }
    private fun closeSettings() {
        settingsPanel?.let { frame.removeView(it) }
        settingsPanel = null
        reveal(true)
    }
    private fun saveProgress() {
        if (::mediaStore.isInitialized && ::entry.isInitialized) {
            runCatching { mediaStore.updateProgress(entry.path, if (completed) 0L else position, length) }
        }
    }
    override fun onBackPressed() {
        if (settingsPanel != null) closeSettings() else super.onBackPressed()
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (settingsPanel != null) return super.onKeyDown(keyCode, event)
        when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_HEADSETHOOK, KeyEvent.KEYCODE_SPACE -> {
                toggle(); reveal(); return true
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> { move(-10_000L); return true }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { move(10_000L); return true }
            KeyEvent.KEYCODE_MENU -> { openSettings(false); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> if (overlay.visibility == View.GONE || surface.hasFocus()) { move(-10_000L); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (overlay.visibility == View.GONE || surface.hasFocus()) { move(10_000L); return true }
            KeyEvent.KEYCODE_DPAD_CENTER -> if (overlay.visibility == View.GONE || surface.hasFocus()) { reveal(true); return true }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN ->
                if (overlay.visibility == View.GONE) { reveal(true); return true }
        }
        return super.onKeyDown(keyCode, event)
    }
    override fun onPause() {
        if (::player.isInitialized && !closed) {
            if (player.isPlaying) player.pause()
            saveProgress()
        }
        super.onPause()
    }
    override fun onDestroy() {
        closed = true
        main.removeCallbacksAndMessages(null)
        if (::player.isInitialized) {
            saveProgress()
            player.setEventListener(null)
            runCatching { player.stop() }
            runCatching { player.vlcVout.detachViews() }
            player.release()
        }
        if (::engine.isInitialized) engine.release()
        super.onDestroy()
    }
}
