package com.aurora.media.firetv

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.util.concurrent.Executors

/** Native TV/D-pad interface: no Compose or AndroidX, compatible with Android API 22. */
class MainActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private val images = Executors.newFixedThreadPool(2)
    private lateinit var store: MediaStore
    private lateinit var posters: PosterLoader
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var grid: GridView
    private var videos: List<Video> = emptyList()
    private var columns = 4
    private var cellWidth = 160
    private var alive = true

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density + 0.5f).toInt()
    private fun bg(color: Int, stroke: Int = Color.TRANSPARENT, r: Int = 10): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(r).toFloat()
            if (stroke != Color.TRANSPARENT) setStroke(dp(3), stroke)
        }
    private fun label(text: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER_VERTICAL
    }
    private fun button(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        isFocusable = true
        setOnClickListener { click() }
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(34, 51, 74))
        setOnFocusChangeListener { v, focused ->
            v.background = bg(if (focused) Color.rgb(36, 76, 132) else Color.rgb(34, 51, 74),
                if (focused) Color.rgb(120, 190, 255) else Color.TRANSPARENT)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        store = MediaStore(this)
        posters = PosterLoader(File(cacheDir, "posters"), images)
        val a = store.readAccount()
        if (!a.valid()) showSetup(a) else {
            showLibrary()
            rescan() // Show cached posters first, then discover newly added FTP files.
        }
    }
    private fun container(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 13, 24))
            setPadding(dp(28), dp(12), dp(28), dp(12))
        }
        setContentView(root)
        return root
    }
    private fun field(hint: String, value: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText =
        EditText(this).apply {
            this.hint = hint
            setText(value)
            inputType = type
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setSelectAllOnFocus(true)
            isFocusableInTouchMode = true
        }

    private fun showSetup(account: FtpAccount) {
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val pane = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(70), dp(14), dp(70), dp(20))
            setBackgroundColor(Color.rgb(8, 13, 24))
        }
        scroll.addView(pane)
        setContentView(scroll)
        pane.addView(label("AURORA MEDIA  /  FIRE TV", 27f).apply { setTypeface(null, Typeface.BOLD) })
        pane.addView(label("One-time FTP setup. Use your remote to select each field.", 15f, Color.LTGRAY))
        val host = field("FTP server IP / hostname", account.host)
        val port = field("Port", account.port.toString(), InputType.TYPE_CLASS_NUMBER)
        val user = field("Username", account.user)
        val pass = field("Password", account.password, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        val folder = field("Media folder", account.root)
        for (view in listOf(host, port, user, pass, folder)) {
            pane.addView(view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)))
        }
        val info = label("FTP credentials are stored privately on this older device, but not encrypted. Use a trusted home network.", 13f, Color.LTGRAY)
        pane.addView(info)
        val connect = button("CONNECT & SCAN") {
            val a = FtpAccount(host.text.toString().trim(), port.text.toString().toIntOrNull() ?: 21,
                user.text.toString(), pass.text.toString(), folder.text.toString().ifBlank { "/" })
            if (!a.valid()) { info.text = "Enter a valid host, username and port."; return@button }
            info.text = "Checking FTP connection…"
            io.execute {
                val result = runCatching { FtpMedia.test(a) }
                runOnUiThread {
                    if (!alive) return@runOnUiThread
                    result.onSuccess { store.saveAccount(a); showLibrary(); rescan() }
                        .onFailure { info.text = "Connection failed: ${it.message}" }
                }
            }
        }
        pane.addView(connect, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(55)))
        connect.requestFocus()
    }

    private fun showLibrary() {
        val view = container()
        videos = store.library()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("AURORA MEDIA", 24f).apply { setTypeface(null, Typeface.BOLD) }, LinearLayout.LayoutParams(0, dp(54), 1f))
        val reload = button("Rescan") { rescan() }
        val config = button("FTP Settings") { showSetup(store.readAccount()) }
        header.addView(reload, LinearLayout.LayoutParams(dp(115), dp(45)))
        header.addView(config, LinearLayout.LayoutParams(dp(160), dp(45)))
        view.addView(header)
        status = label("${videos.size} videos • Press Select for details • Menu to rescan", 14f, Color.LTGRAY)
        view.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)))
        val width = resources.displayMetrics.widthPixels
        columns = (width / dp(192)).coerceIn(3, 6)
        cellWidth = ((width - dp(80)) / columns) - dp(12)
        grid = GridView(this).apply {
            numColumns = columns
            horizontalSpacing = dp(12)
            verticalSpacing = dp(16)
            stretchMode = GridView.NO_STRETCH
            columnWidth = cellWidth
            clipToPadding = false
            setPadding(dp(4), dp(8), dp(4), dp(8))
            isFocusable = true
            isFocusableInTouchMode = true
        }
        grid.adapter = MovieAdapter()
        grid.onItemClickListener = android.widget.AdapterView.OnItemClickListener { _, _, position, _ -> openDetails(videos[position]) }
        grid.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                grid.invalidateViews()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        view.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        view.addView(label("Metadata from TMDb • Not endorsed by TMDb • Original video files remain on your FTP server", 12f, Color.GRAY))
        if (videos.isNotEmpty()) grid.requestFocus() else reload.requestFocus()
    }
    private inner class MovieAdapter : BaseAdapter() {
        override fun getCount() = videos.size
        override fun getItem(position: Int): Any = videos[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val item = videos[position]
            val col = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                isFocusable = false
                background = bg(Color.rgb(16, 26, 41), if (grid.selectedItemPosition == position) Color.rgb(125, 189, 255) else Color.TRANSPARENT)
                setPadding(dp(4), dp(4), dp(4), dp(4))
            }
            val art = ImageView(this@MainActivity).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.rgb(29, 43, 66))
                isFocusable = false
            }
            col.addView(art, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (cellWidth * 1.28f).toInt()))
            posters.show(art, item.poster)
            val title = label(item.title + (item.seasonEpisode?.let { " $it" } ?: ""), 13f).apply {
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setTypeface(null, Typeface.BOLD)
                isFocusable = false
            }
            col.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)))
            return col
        }
    }
    private fun openDetails(video: Video) {
        val msg = buildString {
            append(video.year?.toString()?.plus(" • ") ?: "")
            append(if (video.tv) "TV episode" else "Movie")
            video.seasonEpisode?.let { append(" • $it") }
            append("\n\n")
            append(video.description ?: "No description available yet. Try Rescan to fetch metadata.")
            if (video.savedAt > 0) append("\n\nResume available")
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(video.title)
            .setMessage(msg)
            .setPositiveButton("PLAY") { _, _ ->
                startActivity(Intent(this, PlayerActivity::class.java).putExtra("videoPath", video.path))
            }
            .setNegativeButton("CANCEL", null)
            .create()
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).requestFocus() }
        dialog.show()
    }
    private fun rescan() {
        val a = store.readAccount()
        if (!a.valid()) { showSetup(a); return }
        status.text = "Scanning FTP folders…"
        io.execute {
            try {
                val scanned = FtpMedia.scan(a)
                val old = store.library().associateBy { it.path }
                val updated = scanned.map { item ->
                    old[item.path]?.takeIf { it.size == item.size }?.copy(title = item.title, filename = item.filename) ?: item
                }.toMutableList()
                store.save(updated)
                runOnUiThread {
                    if (alive) { videos = updated.toList(); grid.adapter = MovieAdapter(); status.text = "Found ${videos.size} videos • Loading posters…" }
                }
                var failures = 0
                for (i in updated.indices) {
                    if (Thread.currentThread().isInterrupted) break
                    if (updated[i].tmdbId != 0 || !updated[i].poster.isNullOrEmpty()) continue
                    updated[i] = try { Tmdb.enrich(updated[i]) } catch (_: Exception) { failures++; updated[i] }
                    if (i % 6 == 0 || i == updated.lastIndex) {
                        store.save(updated)
                        val snapshot = updated.toList()
                        runOnUiThread {
                            if (alive) {
                                val selected = grid.selectedItemPosition.coerceAtLeast(0)
                                videos = snapshot
                                grid.adapter = MovieAdapter()
                                if (snapshot.isNotEmpty()) {
                                    grid.setSelection(selected.coerceAtMost(snapshot.lastIndex))
                                    grid.requestFocus()
                                }
                                status.text = "${snapshot.size} videos • Metadata ${i+1}/${snapshot.size}" + if (failures > 0) " • $failures lookups failed" else ""
                            }
                        }
                    }
                }
                store.save(updated)
                runOnUiThread { if (alive) status.text = "${updated.size} videos • Press Select to play • Menu to rescan" }
            } catch (e: Exception) {
                runOnUiThread { if (alive) status.text = "FTP scan failed: ${e.message}" }
            }
        }
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU && ::status.isInitialized) { rescan(); return true }
        return super.onKeyDown(keyCode, event)
    }
    override fun onResume() {
        super.onResume()
        if (::grid.isInitialized && ::status.isInitialized) {
            val saved = store.library()
            if (saved.isNotEmpty() && saved.size == videos.size) { videos = saved; grid.adapter = MovieAdapter() }
        }
    }
    override fun onDestroy() {
        alive = false
        io.shutdownNow(); images.shutdownNow()
        super.onDestroy()
    }
}
