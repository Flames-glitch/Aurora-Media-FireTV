package com.aurora.media.firetv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

data class FtpAccount(
    val host: String = "",
    val port: Int = 21,
    val user: String = "",
    val password: String = "",
    val root: String = "/"
) {
    fun valid() = host.isNotBlank() && port in 1..65535 && user.isNotBlank()
}

data class Video(
    val path: String,
    val title: String,
    val filename: String,
    val size: Long,
    val year: Int? = null,
    val tv: Boolean = false,
    val seasonEpisode: String? = null,
    val poster: String? = null,
    val description: String? = null,
    val tmdbId: Int = 0,
    val savedAt: Long = 0L,
    val duration: Long = 0L
) {
    fun toJson() = JSONObject().apply {
        put("path", path); put("title", title); put("filename", filename)
        put("size", size); put("year", year ?: JSONObject.NULL)
        put("tv", tv); put("seasonEpisode", seasonEpisode ?: JSONObject.NULL)
        put("poster", poster ?: JSONObject.NULL); put("description", description ?: JSONObject.NULL)
        put("tmdbId", tmdbId); put("savedAt", savedAt); put("duration", duration)
    }
    companion object {
        fun fromJson(o: JSONObject) = Video(
            path = o.getString("path"), title = o.optString("title"),
            filename = o.optString("filename"), size = o.optLong("size"),
            year = if (o.isNull("year")) null else o.optInt("year"),
            tv = o.optBoolean("tv"),
            seasonEpisode = o.optString("seasonEpisode").takeUnless { it.isNullOrBlank() || it == "null" },
            poster = o.optString("poster").takeIf { it.startsWith("https://") },
            description = o.optString("description").takeUnless { it.isNullOrBlank() || it == "null" },
            tmdbId = o.optInt("tmdbId"), savedAt = o.optLong("savedAt"), duration = o.optLong("duration")
        )
    }
}

object VideoNames {
    private val validExtensions = setOf("mkv", "mp4", "avi", "m4v", "mov", "wmv", "ts", "m2ts", "flv", "mpg", "mpeg", "webm", "vob", "3gp")
    private val episode = Regex("(?i)S(\\d{1,2})[ ._-]*E(\\d{1,3})")
    private val year = Regex("(?:19|20)\\d{2}")
    private val tags = Regex("(?i)\\b(2160p|1080p|720p|480p|bluray|brrip|bdrip|web-dl|webrip|dvdrip|x264|x265|hevc|h264|h265|aac|dts|hdr|remux)\\b")
    fun parse(path: String, size: Long): Video? {
        val name = path.substringAfterLast('/')
        if (name.substringAfterLast('.', "").lowercase(Locale.US) !in validExtensions) return null
        val stem = name.substringBeforeLast('.')
        val ep = episode.find(stem)
        val yr = year.find(stem)
        val cut = ep?.range?.first ?: yr?.range?.first ?: tags.find(stem)?.range?.first ?: stem.length
        val title = stem.substring(0, cut).replace(Regex("[._]+"), " ")
            .replace(Regex("[\\[\\]()]"), " ").replace(Regex("\\s+"), " ")
            .trim(' ', '-', '_').ifBlank { stem }
        val code = ep?.let { "S${it.groupValues[1].padStart(2, '0')}E${it.groupValues[2].padStart(2, '0')}" }
        return Video(path, title, name, size, yr?.value?.toIntOrNull(), ep != null, code)
    }
}

class MediaStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("firetv", Context.MODE_PRIVATE)
    private val libraryFile = File(context.filesDir, "library.json")
    // Fire OS 5 private preferences are not Keystore-encrypted. Keep this device on a trusted LAN.
    fun readAccount(): FtpAccount = FtpAccount(
        prefs.getString("host", "") ?: "", prefs.getInt("port", 21),
        prefs.getString("user", "") ?: "", prefs.getString("pass", "") ?: "",
        prefs.getString("root", "/") ?: "/"
    )
    fun saveAccount(a: FtpAccount) {
        prefs.edit().putString("host", a.host).putInt("port", a.port)
            .putString("user", a.user).putString("pass", a.password)
            .putString("root", a.root).apply()
    }
    @Synchronized fun library(): List<Video> = try {
        val array = JSONArray(libraryFile.readText())
        (0 until array.length()).map { Video.fromJson(array.getJSONObject(it)) }
    } catch (_: Exception) { emptyList() }
    @Synchronized fun save(items: List<Video>) {
        val temp = File(libraryFile.parentFile, "library.tmp")
        temp.writeText(JSONArray().apply { items.forEach { put(it.toJson()) } }.toString())
        if (!temp.renameTo(libraryFile)) {
            libraryFile.writeText(temp.readText()); temp.delete()
        }
    }
    @Synchronized fun updateProgress(path: String, at: Long, duration: Long) {
        val all = library().toMutableList()
        val index = all.indexOfFirst { it.path == path }
        if (index >= 0) { all[index] = all[index].copy(savedAt = at, duration = duration); save(all) }
    }
}
